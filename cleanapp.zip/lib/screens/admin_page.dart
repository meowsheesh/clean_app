import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'info_page.dart';

class AdminPage extends StatefulWidget {
  const AdminPage({Key? key}) : super(key: key);

  static String id = 'admin_page';

  @override
  State<AdminPage> createState() => _AdminPageState();
}

class _AdminPageState extends State<AdminPage> {
  final _firestore = FirebaseFirestore.instance;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            StreamBuilder<QuerySnapshot>(
              stream: _firestore.collection('container').snapshots(),
              builder: (context, snapshot) {
                if (snapshot.hasData) {
                  final messages = snapshot.data?.docs;
                  List<Widget> messageWidgets = [];
                  for (var message in messages!) {
                    final messageLocation = message['location'];
                    final messageComment = message['comment'];
                    bool isFull = message['sost'];
                    final numCon = message['numCon'];
                    final messageWidget = CubeWidget(
                      isFull: isFull,
                      numCon: numCon,
                      comment: messageComment,
                      location: messageLocation,
                    );
                    messageWidgets.add(messageWidget);
                  }
                  return
                    Expanded(
                      child: GridView.count(
                    physics: const NeverScrollableScrollPhysics(),
                    padding: EdgeInsets.only(top: 15),
                    crossAxisCount: 4,
                    children: messageWidgets,
                  ));
                } else {
                  return Text('No dATA');
                }
                //,style: TextStyle(color: Colors.black),
              },
            )
          ],
        ),
      ),
      appBar: AppBar(
        title: Text('Панель администратора'),
      ),
    );
  }
}

class CubeWidget extends StatelessWidget {
  const CubeWidget(
      {Key? key,
      required this.isFull,
      required this.numCon,
      required this.comment,
      required this.location,
      this.onPressed})
      : super(key: key);

  final Function? onPressed;
  final String location;
  final String comment;
  final int numCon;
  final bool isFull;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: (){
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => InfoPage(comment: comment, sost: isFull, location: location, numCon: numCon,),
          ),
        );
      },
      child: Container(
        child: Column(
          children: [
            Container(
              width: 90,
              height: 90,
              decoration: BoxDecoration(
                color: isFull ? Colors.redAccent : Color(0xFF32B67A),
                borderRadius: BorderRadius.circular(5.0),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.5),
                    spreadRadius: 2,
                    blurRadius: 5,
                    offset: Offset(0, 3), // changes position of shadow
                  ),
                ],
              ),
              child: Center(
                child: Text(
                  numCon.toString(),
                  style: TextStyle(color: Colors.black, fontSize: 20,),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
