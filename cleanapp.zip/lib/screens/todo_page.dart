import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';

import '../reusableTrashWidget.dart';
import 'info_page.dart';

class TodoPage extends StatefulWidget {
  const TodoPage({Key? key}) : super(key: key);
  static String id = 'todo_page';

  @override
  State<TodoPage> createState() => _TodoPageState();
}

class _TodoPageState extends State<TodoPage> {

  final CollectionReference _collectionReference = FirebaseFirestore.instance.collection('container');
  late User loggedInUser;
  final _firestore = FirebaseFirestore.instance;
  final _auth = FirebaseAuth.instance;
  late String comment;
  late String location;
  late bool sost;

  @override
  void initState() {
    super.initState();
    getCurrentUser();
  }

  void messageStream() async {
    await for (var snapshot in _firestore.collection('container').snapshots()) {
      for (var message in snapshot.docs) {
        print(message.data());
      }
    }
  }

  void getCurrentUser() async {
    try {
      final user = await _auth.currentUser;
      if (user != null) {
        loggedInUser = user;
        print(loggedInUser.email);
      }
    } catch (e) {
      print(e);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Список заполненных'),
      ),
      body: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            StreamBuilder<QuerySnapshot>(
              stream: _firestore.collection('container').snapshots(),
              builder: (context, snapshot) {
                if (snapshot.hasData) {
                  final messages = snapshot.data?.docs;
                  List<Widget> messageWidgets = [];
                  for (var message in messages!) {
                    final messageLocation = message['location'];
                    final messageComment = message['comment'];
                    bool isFull = message['sost'];
                    final numCon = message['numCon'];

                      if (isFull == true) {
                        final messageWidget = TrashWidget(isFull: isFull,
                            numCon: numCon,
                            comment: messageComment,
                            location: messageLocation,);
                        messageWidgets.add(messageWidget);
                      }
                  }
                  return Expanded(
                      child: ListView(
                        padding: EdgeInsets.all(5),
                        children: messageWidgets,
                      ));
                } else {
                  return Text('No dATA');
                }
                //,style: TextStyle(color: Colors.black),
              },
            )
          ],
        ),
      ),
    );
  }
}

class TrashWidget extends StatelessWidget {
  TrashWidget({Key? key, required this.isFull, required this.numCon,required this.comment,required this.location, this.onPressed,}) : super(key: key);

  final Function? onPressed;
  final String location;
  final String comment;
  final int numCon;
  final bool isFull;

  final CollectionReference _collectionReference = FirebaseFirestore.instance.collection('container');

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: (){
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => InfoPage(comment: comment, sost: isFull, location: location, numCon: numCon,),
          ),
        );
      },
      child: Container(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 10, top: 10),
                  child: Text(
                    'Контейнер №$numCon',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 24,
                      color: Color(0xFFFFFFFF),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 10, top: 5),
                  child: Text(
                    'Адрес: $location',
                    style: TextStyle(
                      fontSize: 16,
                      color: Color(0xFFFFFFFF),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 10, top: 5),
                  child: Row(
                    children: [
                      Text(
                        comment,
                        style: TextStyle(
                          fontSize: 16,
                          color: Color(0xFFFFFFFF),
                        ),
                      ),

                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
        height: 100,
        margin: EdgeInsets.only(top: 10, left: 10, right: 10),
        decoration: BoxDecoration(
          color: Color(0xFF32B67A),
          borderRadius: BorderRadius.circular(5.0),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.5),
              spreadRadius: 5,
              blurRadius: 7,
              offset: Offset(0, 3), // changes position of shadow
            ),
          ],
        ),
      ),
    );
  }
}
